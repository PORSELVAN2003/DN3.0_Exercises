package com.example.bookstore.repository;

public interface JpaRepository<T1, T2> {

}

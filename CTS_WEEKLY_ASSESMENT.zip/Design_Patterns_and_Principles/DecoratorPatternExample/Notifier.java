public interface Notifier {
    void send(String msg);
}
public class LibraryManagementApplication {
    public static void main(String[] args) {
        
    }

    @Service
    public class BookService {
        public void addBook(Book book) {
            
        }

        public void removeBook(Book book) {
            
        }
    }
}
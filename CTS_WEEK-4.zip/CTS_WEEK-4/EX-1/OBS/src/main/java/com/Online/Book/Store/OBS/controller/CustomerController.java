package com.Online.Book.Store.OBS.controller;



import com.Online.Book.Store.OBS.dto.CustomerDTO;
import com.Online.Book.Store.OBS.entity.CustomerEntity;
import com.Online.Book.Store.OBS.service.CustomerService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@RestController
@RequestMapping("/customers")
@Validated
public class CustomerController {

    @Autowired
    private CustomerService customerService;

    @Autowired
    private ModelMapper modelMapper;


    @PostMapping(consumes = "application/json")
    public ResponseEntity<CustomerEntity> createCustomer(@RequestBody @Valid CustomerDTO customerDTO) {
        CustomerEntity customerEntity = modelMapper.map(customerDTO, CustomerEntity.class);
        CustomerEntity newCustomer = customerService.createCustomer(customerEntity);
        return new ResponseEntity<>(newCustomer, HttpStatus.CREATED);
    }


    @PostMapping(consumes = "application/x-www-form-urlencoded")
    public ResponseEntity<CustomerEntity> createCustomerFromFormData(@RequestParam("name") String name,
                                                                     @RequestParam("email") String email,
                                                                     @RequestParam("password") String password) {
        CustomerDTO customerDTO = new CustomerDTO(name, email, password);
        CustomerEntity customerEntity = modelMapper.map(customerDTO, CustomerEntity.class);
        CustomerEntity newCustomer = customerService.createCustomer(customerEntity);
        return new ResponseEntity<>(newCustomer, HttpStatus.CREATED);
    }
}
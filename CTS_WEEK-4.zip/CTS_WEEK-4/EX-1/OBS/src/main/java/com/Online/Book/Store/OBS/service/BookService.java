package com.Online.Book.Store.OBS.service;

import com.Online.Book.Store.OBS.entity.BookEntity;
import com.Online.Book.Store.OBS.repository.BookRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BookService {

    @Autowired
    private BookRepository bookRepository;

    public BookEntity getBookById(Long id) {
        return bookRepository.findById(id).orElse(null);
    }

    public List<BookEntity> getBooksByTitleAndAuthor(String title, String author) {
        if (title != null && author != null) {
            return bookRepository.findByTitleAndAuthor(title, author);
        } else if (title != null) {
            return bookRepository.findByTitle(title);
        } else if (author != null) {
            return bookRepository.findByAuthor(author);
        } else {
            return bookRepository.findAll();
        }
    }

    // Other service methods (CREATE, UPDATE, DELETE) remain the same
}
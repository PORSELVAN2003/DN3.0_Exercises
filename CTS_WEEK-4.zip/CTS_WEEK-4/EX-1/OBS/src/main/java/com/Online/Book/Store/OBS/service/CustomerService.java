package com.Online.Book.Store.OBS.service;

import com.Online.Book.Store.OBS.entity.CustomerEntity;
import com.Online.Book.Store.OBS.repository.CustomerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CustomerService {

    @Autowired
    private CustomerRepository customerRepository;

    public CustomerEntity createCustomer(CustomerEntity customer) {
        return customerRepository.save(customer);
    }
}
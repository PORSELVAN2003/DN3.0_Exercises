package com.Online.Book.Store.OBS.mapper;

import com.Online.Book.Store.OBS.dto.BookDTO;
import com.Online.Book.Store.OBS.entity.BookEntity;
import org.modelmapper.ModelMapper;

public class BookMapper {
    private static ModelMapper modelMapper = new ModelMapper();

    public static BookDTO toDTO(Book book) {
        return modelMapper.map(book, BookDTO.class);
    }

    public static Book toEntity(BookDTO bookDTO) {
        return modelMapper.map(bookDTO, Book.class);
    }
}
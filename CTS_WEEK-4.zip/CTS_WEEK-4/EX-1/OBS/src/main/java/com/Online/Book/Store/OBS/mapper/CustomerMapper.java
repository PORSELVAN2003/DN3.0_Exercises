package com.Online.Book.Store.OBS.mapper;

import com.Online.Book.Store.OBS.dto.CustomerDTO;
import com.Online.Book.Store.OBS.entity.CustomerEntity;
import org.modelmapper.ModelMapper;

public class CustomerMapper {
    private static ModelMapper modelMapper = new ModelMapper();

    public static CustomerDTO toDTO(Customer customer) {
        return modelMapper.map(customer, CustomerDTO.class);
    }

    public static Customer toEntity(CustomerDTO customerDTO) {
        return modelMapper.map(customerDTO, Customer.class);
    }
}